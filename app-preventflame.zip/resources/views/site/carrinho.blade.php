@extends('layouts.app')

@section('content')

@include('components._page-header')

@endsection
