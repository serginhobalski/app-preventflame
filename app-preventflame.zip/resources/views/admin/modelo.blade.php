@extends('layouts.admin')

@section('styles')
@endsection

@section('content')
@endsection


@section('scripts')
@endsection
