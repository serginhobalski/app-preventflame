<?php if(session('info')): ?>
    <div class="alert alert-info alert-dismissible fade show" role="alert">
        <strong> <?php echo e(session('info')); ?> </strong>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
            
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>
<?php if(session('warning')): ?>
    <div class="alert alert-warning alert-dismissible fade show" role="alert">
        <strong> <?php echo e(session('warning')); ?> </strong>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
            
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>
<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <strong> <?php echo e(session('success')); ?> </strong>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
            
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
<?php endif; ?>
<?php /**PATH /var/www/resources/views/components/flash-message.blade.php ENDPATH**/ ?>